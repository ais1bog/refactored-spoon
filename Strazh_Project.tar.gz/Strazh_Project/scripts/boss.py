import os

DATA_FILE = "status.txt"

def main():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            print("\n=== ОТЧЕТ СИСТЕМНОГО СТРАЖА ===")
            print(f.read())
            print("===============================")
    else:
        print("Бот: Демон еще не собрал данные. Подождите...")

if __name__ == "__main__":
    main()
