import os

# Скрипт сам определяет, в какой папке он лежит
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Все файлы теперь создаются РЯДОМ со скриптом
STATUS_FILE = os.path.join(BASE_DIR, "status.txt")
# Если используешь логи:
LOG_FILE = os.path.join(BASE_DIR, "strazh.log")
import subprocess
import time
import os
from datetime import datetime

# --- НАСТРОЙКИ ---
BASE_DIR = "/home/hren/Bot-kali"
DATA_FILE = os.path.join(BASE_DIR, "status.txt")
# Авто-определение сети (теперь он сам поймет, что у тебя 192.168.0.0/24)
NETWORK_TARGET = "192.168.0.0/24" 

known_devices = {}
last_purge_date = datetime.now().date()
days_counter = 0
PURGE_EVERY_N_DAYS = 3

def get_open_ports(ip):
    try:
        # Быстрый чек портов
        res = subprocess.check_output(f"sudo nmap -F --open {ip} | grep 'open'", shell=True, timeout=5).decode()
        ports = [f"{line.split()[0]}({line.split()[2]})" for line in res.splitlines() if line]
        return ", ".join(ports) if ports else "Порты закрыты"
    except:
        return "Скрыто"

def scan_network():
    devices = {}
    try:
        # Самый мощный способ увидеть всех в локалке — arp-scan
        # Он видит даже тех, кто блокирует пинги
        output = subprocess.check_output("sudo arp-scan --localnet", shell=True).decode()
        
        for line in output.splitlines():
            parts = line.split()
            # Проверяем, что строка начинается с IP адреса
            if len(parts) >= 2 and parts[0].count('.') == 3:
                ip = parts[0]
                # Пропускаем наш собственный IP, чтобы не спамить в отчет
                if ip == "192.168.0.145": continue 
                
                vendor = " ".join(parts[2:]) if len(parts) > 2 else "Unknown Device"
                devices[ip] = vendor
    except Exception as e:
        print(f"[-] Ошибка сканера: {e}. Попробуй: sudo apt install arp-scan")
    return devices

def main():
    global known_devices, last_purge_date, days_counter
    print(f"[*] СТРАЖ АКТИВИРОВАН на сети {NETWORK_TARGET}")
    print("[!] Запуск от ROOT подтвержден.")

    while True:
        now = datetime.now()
        
        # Сброс каждые 3 дня в полночь
        if now.date() > last_purge_date:
            days_counter += 1
            last_purge_date = now.date()
            if days_counter >= PURGE_EVERY_N_DAYS:
                known_devices.clear()
                days_counter = 0

        # Сканируем
        current_scanned = scan_network()
        
        # Обновляем базу
        for ip, name in current_scanned.items():
            if ip not in known_devices:
                print(f"[+] Новый гость: {ip} ({name})")
                ports = get_open_ports(ip)
                known_devices[ip] = {"name": name, "ports": ports}
        
        # Убираем тех, кто отключился
        for ip in list(known_devices.keys()):
            if ip not in current_scanned:
                del known_devices[ip]

        # Пишем подробный отчет
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            f.write(f"ОТЧЕТ РАЗВЕДКИ: {now.strftime('%d.%m %H:%M:%S')}\n")
            f.write(f"Устройств онлайн: {len(known_devices)}\n")
            f.write("-" * 30 + "\n")
            
            if not known_devices:
                f.write("СЕТЬ ПУСТА (проверь подключение)\n")
            
            for ip, info in known_devices.items():
                f.write(f"IP: {ip}\n")
                f.write(f"VENDOR: {info['name']}\n")
                f.write(f"PORTS:  {info['ports']}\n")
                f.write("." * 20 + "\n")

        time.sleep(120)

if __name__ == "__main__":
    main()
