import os

# Скрипт сам определяет, в какой папке он лежит
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Все файлы теперь создаются РЯДОМ со скриптом
STATUS_FILE = os.path.join(BASE_DIR, "status.txt")
# Если используешь логи:
LOG_FILE = os.path.join(BASE_DIR, "strazh.log")
import subprocess
import json
import sys
import os

def main():
    if len(sys.argv) < 2:
        print("Использование: find 'твой вопрос'")
        return

    query = " ".join(sys.argv[1:])
    print(f"\n[*] Глубокий поиск: {query}")
    print("=" * 60)

    try:
        # 1. Ищем через ddgr и берем только ПЕРВУЮ, самую релевантную ссылку
        search_cmd = f"ddgr --json -n 1 '{query}'"
        result = subprocess.check_output(search_cmd, shell=True).decode()
        data = json.loads(result)
        
        if data:
            url = data[0]['url']
            title = data[0]['title']
            print(f"\033[1;34m[*] Источник: {title}\033[0m")
            print(f"[*] Ссылка: {url}")
            print("-" * 60)
            
            # 2. Используем LYNX для вытягивания ЧИСТОГО ТЕКСТА статьи
            # -dump превращает страницу в текст, -nolist убирает список ссылок в конце
            content = subprocess.check_output(['lynx', '-dump', '-nolist', '-display_charset=utf-8', url]).decode()
            
            # 3. Выводим первые 2000 символов (самая суть)
            # Это обычно начало статьи с ответами
            print(content[:2000]) 
            
            print("\n" + "-" * 60)
            print("[!] Текст обрезан для удобства. Полная инфа по ссылке выше.")
        else:
            print("[-] Ничего не найдено.")

    except Exception as e:
        print(f"[-] Ошибка: {e}")

if __name__ == "__main__":
    main()
