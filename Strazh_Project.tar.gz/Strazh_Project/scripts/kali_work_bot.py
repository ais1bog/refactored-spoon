import os

# Путь к файлу, который создает наш фоновый демон
# Используем полный путь, чтобы не было ошибок
STATUS_FILE = "/home/hren/Bot-kali/status.txt"

def main():
    # 1. Проверяем, существует ли файл со статусом
    if not os.path.exists(STATUS_FILE):
        print("Бот: Данные еще не собраны. Убедитесь, что spy_daemon_v2.py запущен.")
        return

    # 2. Читаем данные
    with open(STATUS_FILE, "r", encoding="utf-8") as f:
        report = f.read()

    # 3. Красиво выводим результат
    print("\n" + "="*30)
    print("      ОТЧЕТ СТРАЖА KALI")
    print("="*30)
    print(report)
    print("="*30 + "\n")

if __name__ == "__main__":
    main()
