#!/bin/bash

# Проверка прав root
if [[ $EUID -ne 0 ]]; then
   echo "Ошибка: Запусти скрипт через sudo!"
   exit 1
fi

# Определяем реального пользователя и его домашнюю папку
REAL_USER=$(logname)
USER_HOME=$(eval echo "~$REAL_USER")
INSTALL_DIR="$USER_HOME/Strazh_System"

echo "[*] Установка СТРАЖА для $REAL_USER..."

# Создаем папку установки и копируем скрипты
mkdir -p "$INSTALL_DIR"
cp scripts/*.py "$INSTALL_DIR/"
chown -R $REAL_USER:$REAL_USER "$INSTALL_DIR"
chmod +x "$INSTALL_DIR"/*.py

# Настройка Алиасов в .zshrc (для Kali)
ZSH_RC="$USER_HOME/.zshrc"
if [ -f "$ZSH_RC" ]; then
    sed -i '/# STRAZH_BEGIN/,/# STRAZH_END/d' "$ZSH_RC"
    echo -e "\n# STRAZH_BEGIN
alias boss='cat $INSTALL_DIR/status.txt'
alias ask='python3 $INSTALL_DIR/ask_ai.py'
alias find='python3 $INSTALL_DIR/find_info.py'
alias start-spy='sudo python3 $INSTALL_DIR/spy_daemon_v2.py &'
# STRAZH_END" >> "$ZSH_RC"
fi

echo "[+] Установка завершена! Введите 'source ~/.zshrc' для активации."
